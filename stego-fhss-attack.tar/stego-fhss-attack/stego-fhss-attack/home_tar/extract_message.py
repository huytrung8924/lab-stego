# Tên file: extract_message.py
import numpy as np
import soundfile as sf
import hashlib
import sys

# =====================================
# CONFIG (Phải khớp chính xác với file giấu tin)
# =====================================
SR = 44100
BIT_DURATION = 0.015
BASE_FREQ = 4000
DELTA_HOP = 200
FSK_0 = 1200
FSK_1 = 2200
SECRET_KEY = "FHSS_SECRET"
PREAMBLE = "1010101111001101"

def extract(audio_filename):
    print(f"[+] Loading audio file: {audio_filename} ...")
    try:
        data, rate = sf.read(audio_filename)
    except Exception as e:
        print(f"[-] Error reading file: {e}")
        return

    samples_per_bit = int(BIT_DURATION * rate)
    total_bits_est = len(data) // samples_per_bit
    
    print(f"[+] Total bits estimated: {total_bits_est}")

    # =====================================
    # GENERATE HOPPING PATTERN (Sinh lại khóa)
    # =====================================
    seed = int(hashlib.sha256(SECRET_KEY.encode()).hexdigest(), 16)
    state = seed & 0xFFFF
    pattern = []
    
    for _ in range(total_bits_est):
        new_bit = ((state >> 0) ^ (state >> 2) ^ (state >> 3) ^ (state >> 5)) & 1
        state = ((state >> 1) | (new_bit << 15))
        pattern.append(state % 32)

    # =====================================
    # DEMODULATION (Giải điều chế De-hopping & FSK)
    # =====================================
    extracted_bits = ""
    print("[+] Demodulating signal...")
    
    for i in range(total_bits_est):
        start_idx = i * samples_per_bit
        end_idx = start_idx + samples_per_bit
        chunk = data[start_idx:end_idx]
        
        # Tránh lỗi index out of bounds nếu file bị cắt xén (cropping)
        if len(chunk) < samples_per_bit:
            break
            
        # Tạo sóng mang nội bộ (Local Carrier) để De-hopping
        hop_freq = BASE_FREQ + pattern[i] * DELTA_HOP
        t = np.arange(len(chunk)) / rate
        local_carrier = np.exp(-1j * 2 * np.pi * hop_freq * t)
        
        # De-hopping: Kéo tín hiệu về dải FSK baseband
        baseband = chunk * local_carrier
        
        # Đo năng lượng tại FSK_0 và FSK_1 bằng FFT
        fft_result = np.fft.fft(baseband)
        freqs = np.fft.fftfreq(len(chunk), 1/rate)
        
        # Tìm index của FSK_0 và FSK_1 trên trục tần số
        idx_0 = np.argmin(np.abs(freqs - FSK_0))
        idx_1 = np.argmin(np.abs(freqs - FSK_1))
        
        energy_0 = np.abs(fft_result[idx_0])
        energy_1 = np.abs(fft_result[idx_1])
        
        # Quyết định bit
        if energy_1 > energy_0:
            extracted_bits += "1"
        else:
            extracted_bits += "0"

    # Lưu lại chuỗi bit để lát nữa tính BER
    with open("extracted_bits.txt", "w") as f:
        f.write(extracted_bits)
    print("[+] Saved raw extracted bits to 'extracted_bits.txt'")

    # =====================================
    # SYNC & DECODE (Tìm Preamble và Dịch ra Text)
    # =====================================
    idx = extracted_bits.find(PREAMBLE)
    if idx == -1:
        print("[-] PREAMBLE NOT FOUND! Synchronization failed or signal corrupted.")
        return
        
    print(f"[+] Preamble found at index: {idx}")
    
    # Cắt bỏ Preamble và phần rác phía trước
    payload_bits = extracted_bits[idx + len(PREAMBLE):]
    
    message = ""
    for i in range(0, len(payload_bits), 8):
        byte = payload_bits[i:i+8]
        if len(byte) < 8:
            break
        if byte == "00000000": # Ký tự kết thúc
            break
        char = chr(int(byte, 2))
        message += char

    print("\n==================================")
    print(f"Recovered Message: {message}")
    print("==================================")

if __name__ == "__main__":
    # Kiểm tra xem người dùng đã truyền tên file vào chưa
    if len(sys.argv) != 2:
        print("[-] Lỗi: Thiếu tham số đầu vào.")
        print("Hướng dẫn sử dụng: python3 extract_message.py <file_am_thanh.wav>")
        sys.exit(1)
        
    # Lấy tên file từ command line (sys.argv[1])
    target_audio = sys.argv[1]
    extract(target_audio)
