import numpy as np
import soundfile as sf
import hashlib
import sys

# =====================================
# CONFIG
# =====================================
SR = 44100
BIT_DURATION = 0.015
BASE_FREQ = 4000
DELTA_HOP = 200
FSK_0 = 1200
FSK_1 = 2200

# Khóa sinh chuỗi nhảy tần và Chuỗi mồi đồng bộ
SECRET_KEY = "FHSS_SECRET"
PREAMBLE = "1010101111001101"
MESSAGE = "HELLO FHSS ATTACK"

# Biên độ giấu tin gốc (Cực nhỏ để lẩn trốn vào nhiễu nền)
AMPLITUDE = 0.001

# =====================================
# TEXT -> BITS
# =====================================
def text_to_bits(text):
    bits = "".join(format(ord(c), '08b') for c in text)
    return bits + "00000000" # Ký tự kết thúc (Null byte)

def main():
    if len(sys.argv) != 2:
        print("[-] Usage: python3 embed_fhss.py <host_audio.wav>")
        sys.exit(1)

    host_file = sys.argv[1]

    # 1. Chuyển đổi thông điệp
    payload_bits = text_to_bits(MESSAGE)
    full_bits = PREAMBLE + payload_bits

    with open("original_bits.txt", "w") as f:
        f.write(full_bits)
    print(f"[+] Total bits to embed (including preamble): {len(full_bits)}")

    # 2. Sinh chuỗi nhảy tần (Hopping Pattern)
    seed = int(hashlib.sha256(SECRET_KEY.encode()).hexdigest(), 16)
    state = seed & 0xFFFF
    pattern = []
    
    for _ in range(len(full_bits)):
        new_bit = ((state >> 0) ^ (state >> 2) ^ (state >> 3) ^ (state >> 5)) & 1
        state = ((state >> 1) | (new_bit << 15))
        pattern.append(state % 32)

    # 3. Điều chế tín hiệu (FHSS-FSK Modulation)
    samples_per_bit = int(BIT_DURATION * SR)
    fhss_signal = np.array([], dtype=np.float32)

    print("[+] Modulating FHSS signal...")
    for i, bit in enumerate(full_bits):
        fsk_freq = FSK_1 if bit == '1' else FSK_0
        hop_freq = BASE_FREQ + pattern[i] * DELTA_HOP
        total_freq = hop_freq + fsk_freq
        
        t = np.arange(samples_per_bit) / SR
        tone = np.sin(2 * np.pi * total_freq * t)
        fhss_signal = np.concatenate((fhss_signal, tone))

    # 4. Tải file âm thanh nền (Host Audio)
    try:
        host_audio, sr = sf.read(host_file, dtype='float32')
    except Exception as e:
        print(f"[-] Lỗi đọc file nhạc nền: {e}")
        sys.exit(1)

    if len(host_audio.shape) > 1:
        host_audio = host_audio.mean(axis=1) # Ép về mono

    # Xử lý độ dài: Nếu nhạc ngắn hơn tin giấu thì lặp lại nhạc
    if len(host_audio) < len(fhss_signal):
        repeats = int(np.ceil(len(fhss_signal) / len(host_audio)))
        host_audio = np.tile(host_audio, repeats)
    host_audio = host_audio[:len(fhss_signal)]

    # 5. Nhúng thích nghi (Adaptive Embedding)
    stego_audio = np.copy(host_audio)
    frame_size = 1024
    
    print("[+] Embedding signal adaptively into host audio...")
    for i in range(0, len(fhss_signal), frame_size):
        end = min(i + frame_size, len(fhss_signal))
        host_frame = host_audio[i:end]
        fhss_frame = fhss_signal[i:end]

        # Tính năng lượng khung nhạc nền để giấu mạnh/yếu tương ứng
        energy = np.mean(np.abs(host_frame))
        adaptive_amp = AMPLITUDE * (0.5 + energy * 5)
        
        stego_audio[i:end] += (fhss_frame * adaptive_amp)

    stego_audio = np.clip(stego_audio, -1.0, 1.0) # Chống xé tiếng

    # 6. Lưu file
    sf.write("stego_audio.wav", stego_audio, SR)
    print("\n[+] XONG! Đã tạo stego_audio.wav")

if __name__ == "__main__":
    main()
