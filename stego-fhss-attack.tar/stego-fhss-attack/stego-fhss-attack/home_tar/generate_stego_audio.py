import numpy as np
import soundfile as sf
import hashlib

# =====================================
# CONFIG
# =====================================

SR = 44100

BIT_DURATION = 0.015

BASE_FREQ = 4000

DELTA_HOP = 200

FSK_0 = 1200

FSK_1 = 2200

SECRET_KEY = "FHSS_SECRET"

PREAMBLE = "1010101111001101"

MESSAGE = "HELLO FHSS ATTACK"

# =====================================
# TEXT -> BITS
# =====================================

bits = ""

for c in MESSAGE:

    bits += format(
        ord(c),
        '08b'
    )

# END SYMBOL

bits += "00000000"

# ADD PREAMBLE

full_bits = PREAMBLE + bits

# SAVE ORIGINAL BITS

with open(
    "original_bits.txt",
    "w"
) as f:

    f.write(full_bits)

# =====================================
# GENERATE HOPPING PATTERN
# =====================================

seed = int(
    hashlib.sha256(
        SECRET_KEY.encode()
    ).hexdigest(),
    16
)

state = seed & 0xFFFF

pattern = []

for _ in range(len(full_bits)):

    new_bit = (
        ((state >> 0) ^
         (state >> 2) ^
         (state >> 3) ^
         (state >> 5)) & 1
    )

    state = (
        (state >> 1) |
        (new_bit << 15)
    )

    pattern.append(
        state % 32
    )

# =====================================
# FHSS MODULATION
# =====================================

samples_per_bit = int(
    BIT_DURATION * SR
)

signal = np.array([])

for i, bit in enumerate(full_bits):

    if bit == '0':

        fsk_freq = FSK_0

    else:

        fsk_freq = FSK_1

    hop_freq = (
        BASE_FREQ +
        pattern[i] * DELTA_HOP
    )

    total_freq = (
        hop_freq +
        fsk_freq
    )

    t = np.arange(
        samples_per_bit
    ) / SR

    tone = 0.5 * np.sin(
        2 * np.pi *
        total_freq * t
    )

    signal = np.concatenate(
        (signal, tone)
    )

# =====================================
# SAVE AUDIO
# =====================================

sf.write(
    "stego_audio.wav",
    signal,
    SR
)

print("\n[+] stego_audio.wav created")
