# Tên file: calculate_ber.py

import sys

def calculate_ber(orig_file, ext_file):

    try:

        with open(orig_file, 'r') as f1:
            orig_bits = f1.read().strip()

        with open(ext_file, 'r') as f2:
            ext_bits = f2.read().strip()

        total_orig = len(orig_bits)
        total_ext = len(ext_bits)

        if total_orig == 0:

            print("[-] Original bits file is empty.")
            return

        # =====================================
        # COUNT ERRORS
        # =====================================

        errors = 0

        for i in range(total_orig):

            # thiếu bit do mất sync
            if i >= total_ext:

                errors += 1

            elif orig_bits[i] != ext_bits[i]:

                errors += 1

        # bit rác dư
        extra_garbage = max(
            0,
            total_ext - total_orig
        )

        # =====================================
        # BER
        # =====================================

        ber = errors / total_orig

        # =====================================
        # OUTPUT
        # =====================================

        print("\n========== BER RESULT ==========")

        print("[+] Original Bits :", total_orig)
        print("[+] Extracted Bits:", total_ext)

        if extra_garbage > 0:

            print("[+] Extra Garbage Bits:",
                  extra_garbage)

        print("[+] Errors :", errors)

        print("[+] BER =", ber)

        print("================================")

        # =====================================
        # STATUS
        # =====================================

        if ber > 0.1:

            print("\n[+] STATUS:")
            print("Attack SUCCESSFUL")
            print("Hidden message heavily corrupted")

        elif ber > 0:

            print("\n[!] STATUS:")
            print("Partial corruption detected")

        else:

            print("\n[-] STATUS:")
            print("Perfect extraction")

    except FileNotFoundError as e:

        print("[-] File not found:", e)

    except Exception as e:

        print("[-] Error:", e)

# =====================================
# MAIN
# =====================================

if __name__ == "__main__":

    if len(sys.argv) != 3:

        print(
            "Usage:\n"
            "python calculate_ber.py "
            "original_bits.txt extracted_bits.txt"
        )

    else:

        calculate_ber(
            sys.argv[1],
            sys.argv[2]
        )
