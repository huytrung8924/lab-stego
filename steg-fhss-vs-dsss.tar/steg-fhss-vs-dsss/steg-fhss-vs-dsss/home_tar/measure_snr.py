import numpy as np
import soundfile as sf
import sys

def calculate_snr(host_file, stego_file):
    host_data, _ = sf.read(host_file)
    stego_data, _ = sf.read(stego_file)

    # Đưa về Mono nếu cần
    if len(host_data.shape) > 1: host_data = host_data[:, 0]
    if len(stego_data.shape) > 1: stego_data = stego_data[:, 0]

    # Đảm bảo 2 mảng bằng độ dài nhau
    min_len = min(len(host_data), len(stego_data))
    host_data = host_data[:min_len]
    stego_data = stego_data[:min_len]

    # Tính toán công suất
    signal_power = np.sum(host_data ** 2)
    noise_power = np.sum((host_data - stego_data) ** 2)

    if noise_power == 0:
        return float('inf')
    
    snr = 10 * np.log10(signal_power / noise_power)
    return snr

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python measure_snr.py <host_audio.wav> <stego_fhss.wav> <stego_dsss.wav>")
        sys.exit(1)
        
    snr_fhss = calculate_snr(sys.argv[1], sys.argv[2])
    snr_dsss = calculate_snr(sys.argv[1], sys.argv[3])
    
    print("\n========== KẾT QUẢ ĐO SNR ==========")
    print(f"SNR của FHSS : {snr_fhss:.2f} dB")
    print(f"SNR của DSSS : {snr_dsss:.2f} dB")
    print("====================================")
