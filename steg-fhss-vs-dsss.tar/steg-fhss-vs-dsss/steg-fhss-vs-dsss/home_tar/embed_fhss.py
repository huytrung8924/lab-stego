#embed_fhss
import numpy as np
import soundfile as sf
import random
import hashlib
import sys

# =====================================
# CONFIG
# =====================================

SR = 44100

BIT_DURATION = 0.03      
SAMPLES_PER_BIT = int(SR * BIT_DURATION)

BASE_FREQ = 5000
DELTA_FREQ = 300

HOP_RANGE = (1, 8)

AMPLITUDE = 0.0001

SECRET_KEY = "FHSS_SECRET"

# =====================================
# TEXT -> BITS
# =====================================

def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)

# =====================================
# GENERATE SECURE HOPPING PATTERN
# =====================================

def generate_hopping_pattern(length, key):

    seed = int(
        hashlib.sha256(key.encode()).hexdigest(),
        16
    ) % (2**32)

    rng = random.Random(seed)

    pattern = [
        rng.randint(*HOP_RANGE)
        for _ in range(length)
    ]

    return pattern

# =====================================
# FHSS-FSK MODULATION
# =====================================

def modulate_fhss(bits, hopping_pattern):

    t = np.linspace(
        0,
        BIT_DURATION,
        SAMPLES_PER_BIT,
        endpoint=False
    )

    signal = np.array([], dtype=np.float32)

    for i, bit in enumerate(bits):

        hop = hopping_pattern[i]

        # Frequency hopping
        if bit == '0':
            freq = BASE_FREQ + hop * DELTA_FREQ
        else:
            freq = BASE_FREQ + (hop + 1) * DELTA_FREQ

        tone = np.sin(
            2 * np.pi * freq * t
        )

        signal = np.concatenate(
            (signal, tone.astype(np.float32))
        )

    return signal

# =====================================
# ADAPTIVE EMBEDDING
# =====================================

def adaptive_embed(host_audio, fhss_signal):

    stego = np.copy(host_audio)

    if len(fhss_signal) > len(host_audio):
        raise ValueError(
            "Host audio quá ngắn"
        )

    frame_size = 1024

    for i in range(0, len(fhss_signal), frame_size):

        host_frame = host_audio[i:i+frame_size]

        fhss_frame = fhss_signal[i:i+frame_size]

        if len(host_frame) == 0:
            break

        # Energy adaptive
        energy = np.mean(np.abs(host_frame))

        adaptive_amp = AMPLITUDE * (
            0.5 + energy * 5
        )

        stego[i:i+len(fhss_frame)] += (
            fhss_frame * adaptive_amp
        )

    # Anti clipping
    stego = np.clip(stego, -1.0, 1.0)

    return stego

# =====================================
# MAIN
# =====================================

def main():

    if len(sys.argv) != 2:
        print(
            "Usage: python3 embed_fhss.py host.wav"
        )
        sys.exit(1)

    host_file = sys.argv[1]

    # =====================================
    # SECRET MESSAGE
    # =====================================

    message = "Hello FHSS Steganography!"

    print("\n[+] Message:")
    print(message)

    # =====================================
    # MESSAGE -> BITS
    # =====================================

    bits = text_to_bits(message)

    # No synchronization preamble; embed raw message bits

    print(f"[+] Total bits: {len(bits)}")

    with open("original_bits_fhss.txt", "w") as f:
        f.write(bits)


    # =====================================
    # GENERATE HOPPING PATTERN
    # =====================================

    hopping_pattern = generate_hopping_pattern(
        len(bits),
        SECRET_KEY
    )

    with open("hopping_pattern_fhss.txt", "w") as f:
        f.write(
            " ".join(map(str, hopping_pattern))
        )

    print("[+] Hopping pattern generated")

    # =====================================
    # FHSS MODULATION
    # =====================================

    fhss_signal = modulate_fhss(
        bits,
        hopping_pattern
    )

    print("[+] FHSS modulation completed")

    # =====================================
    # LOAD HOST AUDIO
    # =====================================

    host_audio, sr = sf.read(
        host_file,
        dtype='float32'
    )

    # Stereo -> mono
    if len(host_audio.shape) > 1:
        host_audio = host_audio.mean(axis=1)

    if sr != SR:
        print(
            f"[-] Sample rate phải là {SR}"
        )
        sys.exit(1)

    # =====================================
    # EMBED
    # =====================================

    stego_audio = adaptive_embed(
        host_audio,
        fhss_signal
    )

    # =====================================
    # SAVE OUTPUT
    # =====================================

    output_file = "stego_audio_fhss.wav"

    sf.write(
        output_file,
        stego_audio,
        SR
    )

    print(f"\n[+] Saved: {output_file}")

    print("\n========== DONE ==========")

    print("Generated files:")
    print("- stego_audio_fhss.wav")
    print("- original_bits_fhss.txt")
    print("- hopping_pattern_fhss.txt")

# =====================================
# RUN
# =====================================

if __name__ == "__main__":
    main()
