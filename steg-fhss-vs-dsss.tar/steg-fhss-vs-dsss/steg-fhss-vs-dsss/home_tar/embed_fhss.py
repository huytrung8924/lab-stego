import numpy as np
import soundfile as sf
import random
import sys

# =====================================
# CONFIG
# =====================================

SR = 44100
BIT_DURATION = 0.015       # 15ms mỗi bit
BASE_FREQ = 4000
DELTA_FREQ = 100
HOP_RANGE = (1, 5)
AMPLITUDE = 0.0005 

# =====================================
# STEP 1: TEXT -> BITS
# =====================================

def text_to_bits(text):
    return ''.join(format(ord(c), '08b') for c in text)

# =====================================
# STEP 2: GENERATE HOPPING PATTERN
# =====================================

def generate_hopping_pattern(length, hop_range=(1, 5)):
    return [random.randint(*hop_range) for _ in range(length)]

# =====================================
# STEP 3: FHSS-FSK MODULATION
# =====================================

def modulate_fhss(bits, fs, hopping_pattern,
                  base_freq=BASE_FREQ, # Đã sửa lỗi hardcode 2000 ở đây
                  delta=DELTA_FREQ):

    samples_per_bit = int(fs * BIT_DURATION)

    t = np.linspace(
        0,
        BIT_DURATION,
        samples_per_bit,
        endpoint=False
    )

    signal = np.array([], dtype=np.float32)

    for i, bit in enumerate(bits):

        hop = hopping_pattern[i]

        # Bit 0
        if bit == '0':
            freq = base_freq + hop * delta

        # Bit 1
        else:
            freq = base_freq + (hop + 1) * delta

        tone = np.sin(2 * np.pi * freq * t)

        signal = np.concatenate(
            (signal, tone.astype(np.float32))
        )

    return signal

# =====================================
# STEP 4: EMBED SIGNAL INTO AUDIO
# =====================================

def embed_signal(host_audio, fhss_signal):

    stego = np.copy(host_audio)

    if len(fhss_signal) > len(host_audio):
        raise ValueError(
            "Host audio quá ngắn để chứa dữ liệu"
        )

    stego[:len(fhss_signal)] += fhss_signal

    # tránh clipping
    stego = np.clip(stego, -1.0, 1.0)

    return stego

# =====================================
# MAIN
# =====================================

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 embed_fhss.py host_audio.wav")
        sys.exit(1)

    host_audio_file = sys.argv[1]

    # =====================================
    # MESSAGE TO HIDE
    # =====================================

    message = "Hello FHSS Steganography!"

    print("\n[+] Message:")
    print(message)

    # =====================================
    # STEP 1
    # =====================================

    bits = text_to_bits(message)

    with open("original_bits_fhss.txt", "w") as f:
        f.write(bits)

    print("\n[+] Saved: original_bits_fhss.txt")
    print(f"[+] Total bits: {len(bits)}")

    # save message length for extractor
    with open("message_len_fhss.txt", "w") as f:
        f.write(str(len(bits)))

    # =====================================
    # STEP 2
    # =====================================

    hopping_pattern = generate_hopping_pattern(
        len(bits),
        HOP_RANGE
    )

    with open("hopping_pattern_fhss.txt", "w") as f:
        f.write(
            " ".join(map(str, hopping_pattern))
        )

    print("[+] Saved: hopping_pattern_fhss.txt")

    # =====================================
    # STEP 3
    # =====================================

    fhss_signal = modulate_fhss(
        bits,
        SR,
        hopping_pattern,
        BASE_FREQ,
        DELTA_FREQ
    )

    # Đã sửa lại để sử dụng biến AMPLITUDE chung
    fhss_signal *= AMPLITUDE

    print("[+] FHSS modulation completed")

    # =====================================
    # LOAD HOST AUDIO
    # =====================================

    host_audio, sr = sf.read(
        host_audio_file,
        dtype='float32'
    )

    # stereo -> mono
    if len(host_audio.shape) > 1:
        host_audio = host_audio.mean(axis=1)

    if sr != SR:
        print(
            f"[-] Sample rate phải là {SR} Hz"
        )
        sys.exit(1)

    # =====================================
    # STEP 4
    # =====================================

    stego_audio = embed_signal(
        host_audio,
        fhss_signal
    )

    # =====================================
    # SAVE OUTPUT
    # =====================================

    output_file = "stego_audio_fhss.wav"

    sf.write(
        output_file,
        stego_audio,
        SR
    )

    print(f"\n[+] Saved: {output_file}")

    print("\n========== DONE ==========")
    print("Input : host_audio.wav")
    print("Output:")
    print("- stego_audio_fhss.wav")
    print("- original_bits_fhss.txt")
    print("- hopping_pattern_fhss.txt")

if __name__ == "__main__":
    main()
