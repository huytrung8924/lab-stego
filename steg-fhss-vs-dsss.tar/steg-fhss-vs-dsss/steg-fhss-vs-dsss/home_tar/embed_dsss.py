#embed_dsss.py
import numpy as np
import soundfile as sf
import hashlib
import sys

# =====================================
# CONFIG
# =====================================

BIT_DURATION = 0.03
BASE_FREQ = 5000

SECRET_KEY = "DSSS_SECRET"

MESSAGE = "Hello DSSS Steganography!"

AMPLITUDE = 0.0001

# =====================================
# MAIN
# =====================================

def main():

    if len(sys.argv) < 2:

        print("Usage: python3 embed_dsss.py host_audio.wav")
        sys.exit(1)

    host_file = sys.argv[1]

    # =====================================
    # MESSAGE TO HIDE
    # =====================================

    print("\n[+] Message:")
    print(MESSAGE)

    bits = ""

    for c in MESSAGE:

        bits += format(
            ord(c),
            '08b'
        )

    message_bits = bits
    full_bits = message_bits

    with open(
        "original_bits_dsss.txt",
        "w"
    ) as f:

        f.write(message_bits)

    print("\n[+] Saved: original_bits_dsss.txt")
    print(f"[+] Total bits: {len(message_bits)}")

    # save message length for extractor
    # =====================================
    # LOAD AUDIO
    # =====================================

    try:

        host_data, SR = sf.read(host_file)

    except Exception as e:

        print(
            f"[-] Lỗi khi đọc file: {e}"
        )

        sys.exit(1)

    # stereo -> mono
    if len(host_data.shape) > 1:

        host_data = host_data[:, 0]

        print(
            "[!] Stereo -> Mono"
        )

    # =====================================
    # PN SEQUENCE
    # =====================================

    seed = int(
        hashlib.sha256(
            SECRET_KEY.encode()
        ).hexdigest(),
        16
    ) % (2**32)

    np.random.seed(seed)

    samples_per_bit = int(
        BIT_DURATION * SR
    )

    total_samples = (
        len(full_bits)
        * samples_per_bit
    )

    if total_samples > len(host_data):

        print(
            "[-] Audio quá ngắn"
        )

        sys.exit(1)

    pn_sequence = np.random.choice(
        [-1, 1],
        size=total_samples
    )

    with open(
        "pn_sequence_dsss.txt",
        "w"
    ) as f:

        f.write(
            " ".join(map(str, pn_sequence))
        )

    print("[+] Saved: pn_sequence_dsss.txt")

    # =====================================
    # DSSS MODULATION
    # =====================================

    dsss_signal = np.zeros(
        total_samples
    )

    t = np.arange(
        total_samples
    ) / SR

    carrier = np.sin(
        2 * np.pi * BASE_FREQ * t
    )

    for i, bit in enumerate(full_bits):

        start_idx = i * samples_per_bit
        end_idx = start_idx + samples_per_bit

        symbol = 1 if bit == '1' else -1

        dsss_signal[
            start_idx:end_idx
        ] = (
            symbol
            * pn_sequence[start_idx:end_idx]
            * carrier[start_idx:end_idx]
        )

#    # Hann window
#    window = np.hanning(
#        total_samples
#    )

#    dsss_signal *= window

    # =====================================
    # ADAPTIVE EMBEDDING (match FHSS adaptive rule)
    # =====================================

    stego_audio = host_data.copy()

    frame_size = 1024

    for i in range(0, total_samples, frame_size):

        host_frame = stego_audio[i:i+frame_size]

        signal_frame = dsss_signal[i:i+frame_size]

        if len(host_frame) == 0:
            break

        energy = np.mean(np.abs(host_frame))

        adaptive_amp = AMPLITUDE * (
            0.5 + energy * 5
        )

        stego_audio[i:i+len(signal_frame)] += (
            signal_frame * adaptive_amp
        )

    # anti clipping
    stego_audio = np.clip(stego_audio, -1.0, 1.0)

    # =====================================
    # SAVE
    # =====================================

    output_file = "stego_audio_dsss.wav"

    sf.write(
        output_file,
        stego_audio,
        SR
    )

    print("[+] DSSS modulation completed")

    print(f"\n[+] Saved: {output_file}")

    print("\n========== DONE ==========")
    print(f"Input : {host_file}")
    print("Output:")
    print("- stego_audio_dsss.wav")
    print("- original_bits_dsss.txt")
    print("- pn_sequence_dsss.txt")

# =====================================
# RUN
# =====================================

if __name__ == "__main__":
    main()

