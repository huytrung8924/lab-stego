import sys


def is_bit_string(text):
    return len(text) > 0 and set(text) <= {"0", "1"}


def calculate_ber(orig_file, ext_file):
    with open(orig_file, "r", encoding="utf-8") as f1:
        orig_bits = f1.read().strip()

    with open(ext_file, "r", encoding="utf-8") as f2:
        ext_bits = f2.read().strip()

    if not is_bit_string(orig_bits):
        print(f"[-] Invalid original bits file: {orig_file}")
        return

    if not is_bit_string(ext_bits):
        print(f"[-] Invalid extracted bits file: {ext_file}")
        return

    total_orig = len(orig_bits)
    if total_orig == 0:
        print("BER: 0")
        return

    compare_len = min(total_orig, len(ext_bits))
    errors = sum(
        1
        for i in range(compare_len)
        if orig_bits[i] != ext_bits[i]
    )

    if len(ext_bits) < total_orig:
        errors += total_orig - len(ext_bits)

    ber = errors / total_orig
    print(f"BER: {ber}")

# =====================================
# MAIN
# =====================================

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 calculate_ber.py <original_bits.txt> <extracted_bits.txt>")
    else:
        calculate_ber(sys.argv[1], sys.argv[2])
