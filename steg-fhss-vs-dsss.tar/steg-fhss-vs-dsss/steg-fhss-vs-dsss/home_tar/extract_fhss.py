#extract_fhss
import numpy as np
import soundfile as sf
import hashlib
import random
import sys

# =====================================
# CONFIG
# =====================================

SR = 44100

BIT_DURATION = 0.03
SAMPLES_PER_BIT = int(SR * BIT_DURATION)

BASE_FREQ = 5000
DELTA_FREQ = 300

HOP_RANGE = (1, 8)

SECRET_KEY = "FHSS_SECRET"

# =====================================
# BITS -> TEXT
# =====================================

def bits_to_text(bits):

    chars = []

    for i in range(0, len(bits), 8):

        byte = bits[i:i+8]

        if len(byte) < 8:
            continue

        chars.append(
            chr(int(byte, 2))
        )

    return ''.join(chars)

# =====================================
# GENERATE HOPPING PATTERN
# =====================================

def generate_hopping_pattern(length, key):

    seed = int(
        hashlib.sha256(key.encode()).hexdigest(),
        16
    ) % (2**32)

    rng = random.Random(seed)

    pattern = [
        rng.randint(*HOP_RANGE)
        for _ in range(length)
    ]

    return pattern

# =====================================
# GOERTZEL DETECTOR
# =====================================

def goertzel_power(segment, freq, fs):

    n = len(segment)

    k = int(
        0.5 + (n * freq / fs)
    )

    omega = (
        2.0 * np.pi * k
    ) / n

    coeff = 2.0 * np.cos(omega)

    q0 = 0
    q1 = 0
    q2 = 0

    window = np.hanning(n)

    segment = (
        segment - np.mean(segment)
    ) * window

    for sample in segment:

        q0 = coeff * q1 - q2 + sample
        q2 = q1
        q1 = q0

    power = (
        q1**2 +
        q2**2 -
        q1 * q2 * coeff
    )

    return power

# =====================================
# BANDPASS FILTER
# =====================================

def fft_bandpass(
        segment,
        fs,
        low_cut,
        high_cut):

    spectrum = np.fft.rfft(segment)

    freqs = np.fft.rfftfreq(
        len(segment),
        d=1/fs
    )

    mask = (
        (freqs >= low_cut) &
        (freqs <= high_cut)
    )

    filtered = np.fft.irfft(
        spectrum * mask,
        n=len(segment)
    )

    return filtered.astype(np.float32)

# =====================================
# EXTRACT FHSS
# =====================================

def extract_bits(
        signal,
        total_bits):

    hopping_pattern = generate_hopping_pattern(
        total_bits,
        SECRET_KEY
    )

    extracted = ""

    low_cut = (
        BASE_FREQ - 500
    )

    high_cut = (
        BASE_FREQ +
        (max(HOP_RANGE) + 2)
        * DELTA_FREQ
    )

    for i in range(total_bits):

        start = i * SAMPLES_PER_BIT
        end = start + SAMPLES_PER_BIT

        segment = signal[start:end]

        if len(segment) < SAMPLES_PER_BIT:
            break

        filtered = fft_bandpass(
            segment,
            SR,
            low_cut,
            high_cut
        )

        hop = hopping_pattern[i]

        f0 = (
            BASE_FREQ +
            hop * DELTA_FREQ
        )

        f1 = (
            BASE_FREQ +
            (hop + 1)
            * DELTA_FREQ
        )

        p0 = goertzel_power(
            filtered,
            f0,
            SR
        )

        p1 = goertzel_power(
            filtered,
            f1,
            SR
        )

        if p1 > p0:
            extracted += '1'
        else:
            extracted += '0'

    return extracted

# =====================================
# FIND PREAMBLE
# =====================================

# No preamble search: payload starts at bit 0

# =====================================
# MAIN
# =====================================

def main():

    if len(sys.argv) != 2:

        print(
            "Usage: python3 extract_fhss.py stego.wav"
        )

        sys.exit(1)

    stego_file = sys.argv[1]

    # =====================================
    # LOAD AUDIO
    # =====================================

    audio, sr = sf.read(
        stego_file,
        dtype='float32'
    )

    if len(audio.shape) > 1:
        audio = audio.mean(axis=1)

    if sr != SR:

        print(
            f"[-] Sample rate phải là {SR}"
        )

        sys.exit(1)

    # =====================================
    # LOAD MESSAGE LENGTH (from original_bits_fhss.txt)
    # =====================================

    try:
        with open("original_bits_fhss.txt", "r") as f:
            total_bits = len(f.read().strip())
    except Exception:
        print("[-] Không tìm thấy original_bits_fhss.txt")
        sys.exit(1)

    # =====================================
    # EXTRACT RAW BITS
    # =====================================

    needed_samples = (
        total_bits *
        SAMPLES_PER_BIT
    )

    signal = audio[:needed_samples]

    extracted_bits = extract_bits(
        signal,
        total_bits
    )

    # No preamble: payload is entire extracted_bits (trim to requested length)
    payload_bits = extracted_bits[:total_bits]

    # =====================================
    # SAVE BITS
    # =====================================

    with open(
        "extracted_bits_fhss.txt",
        "w"
    ) as f:

        f.write(payload_bits)

    print(
        "[+] Saved: extracted_bits_fhss.txt"
    )

    # =====================================
    # RECOVER TEXT
    # =====================================

    message = bits_to_text(
        payload_bits
    )

    print("\n[+] Recovered Message:")
    print(message)

    print("\n========== DONE ==========")

# =====================================
# RUN
# =====================================

if __name__ == "__main__":
    main()
