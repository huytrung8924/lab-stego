#extract_fhss.py
import numpy as np
import soundfile as sf
import sys

# =====================================
# CONFIG
# =====================================

SR = 44100
BIT_DURATION = 0.015

BASE_FREQ = 4000
DELTA_FREQ = 100

# =====================================
# BITS -> TEXT
# =====================================

def bits_to_text(bits):

    chars = []

    for i in range(0, len(bits), 8):

        byte = bits[i:i+8]

        if len(byte) < 8:
            continue

        chars.append(
            chr(int(byte, 2))
        )

    return ''.join(chars)

# =====================================
# SIGNAL HELPERS
# =====================================

def band_limit_segment(
        segment,
        fs,
        low_cut,
        high_cut):

    spectrum = np.fft.rfft(segment)
    freqs = np.fft.rfftfreq(
        len(segment),
        d=1 / fs
    )

    mask = (
        (freqs >= low_cut) &
        (freqs <= high_cut)
    )

    filtered = np.fft.irfft(
        spectrum * mask,
        n=len(segment)
    )

    return filtered.astype(np.float32)


def tone_score(segment, fs, freq):

    if len(segment) == 0:
        return 0.0

    window = np.hanning(len(segment))
    if not np.any(window):
        window = np.ones(len(segment))

    centered = segment - np.mean(segment)
    weighted = centered * window

    t = np.arange(len(segment)) / fs
    ref_sin = np.sin(2 * np.pi * freq * t)
    ref_cos = np.cos(2 * np.pi * freq * t)

    sin_proj = np.dot(weighted, ref_sin)
    cos_proj = np.dot(weighted, ref_cos)

    return (sin_proj ** 2 + cos_proj ** 2) / (np.sum(window ** 2) + 1e-12)

# =====================================
# EXTRACT FHSS
# =====================================

def extract_fhss(
        signal,
        fs,
        hopping_pattern):

    samples_per_bit = int(
        fs * BIT_DURATION
    )

    low_cut = max(
        0,
        BASE_FREQ + min(hopping_pattern) * DELTA_FREQ - 200
    )
    high_cut = (
        BASE_FREQ +
        (max(hopping_pattern) + 1) * DELTA_FREQ +
        200
    )

    extracted_bits = ''

    for i, hop in enumerate(hopping_pattern):

        start = i * samples_per_bit
        end = start + samples_per_bit

        segment = signal[start:end]

        filtered_segment = band_limit_segment(
            segment,
            fs,
            low_cut,
            high_cut
        )

        # tần số bit 0
        f0 = BASE_FREQ + hop * DELTA_FREQ

        # tần số bit 1
        f1 = BASE_FREQ + (hop + 1) * DELTA_FREQ

        power_f0 = tone_score(
            filtered_segment,
            fs,
            f0
        )

        power_f1 = tone_score(
            filtered_segment,
            fs,
            f1
        )

        if power_f1 > power_f0:
            extracted_bits += '1'
        else:
            extracted_bits += '0'

    return extracted_bits

# =====================================
# MAIN
# =====================================

if len(sys.argv) != 2:

    print(
        "Usage:python3 extract_fhss.py stego_audio_fhss.wav"
    )

    sys.exit(1)

stego_audio_file = sys.argv[1]

# =====================================
# LOAD STEGO AUDIO
# =====================================

audio, sr = sf.read(
    stego_audio_file,
    dtype='float32'
)

# stereo -> mono
if len(audio.shape) > 1:
    audio = audio.mean(axis=1)

if sr != SR:

    print(
        f"[-] Sample rate phải là {SR}"
    )

    sys.exit(1)

# =====================================
# LOAD HOPPING PATTERN
# =====================================

try:

    with open(
        "hopping_pattern_fhss.txt",
        "r"
    ) as f:

        hopping_pattern = [
            int(x)
            for x in f.read().strip().split()
        ]

except:

    print(
        "[-] Không tìm thấy hopping_pattern_fhss.txt"
    )

    sys.exit(1)

if len(hopping_pattern) == 0:
    print("[-] Hopping pattern rỗng")
    sys.exit(1)

# =====================================
# CHỈ LẤY PHẦN CÓ CHỨA TIN
# =====================================

samples_per_bit = int(
    sr * BIT_DURATION
)

needed_samples = (
    len(hopping_pattern)
    * samples_per_bit
)

signal = audio[:needed_samples]

# =====================================
# EXTRACT BITS
# =====================================

extracted_bits = extract_fhss(
    signal,
    sr,
    hopping_pattern
)

# =====================================
# SAVE BITS
# =====================================

with open(
    "extracted_bits_fhss.txt",
    "w"
) as f:
    # if producer saved message length, trim residuals
    try:
        with open("message_len_fhss.txt", "r") as lf:
            msg_len = int(lf.read().strip())
            trimmed = extracted_bits[:msg_len]
    except Exception:
        trimmed = extracted_bits

    f.write(trimmed)

print("[+] Saved: extracted_bits_fhss.txt")

recovered_message = bits_to_text(trimmed)

print("\n[+] Message:")
print(recovered_message)
