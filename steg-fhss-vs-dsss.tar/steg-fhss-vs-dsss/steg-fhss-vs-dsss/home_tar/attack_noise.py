import numpy as np
import soundfile as sf
import sys
import subprocess
import os

# =====================================
# 1. CÁC HÀM TẠO NHIỄU (ATTACKS)
# =====================================

def add_broadband_noise(data, noise_level=0.005):
    noise = np.random.normal(0, noise_level, data.shape)
    return data + noise

def add_narrowband_noise(data, sr, jam_freq=5000, jam_amp=0.05):
    t = np.arange(len(data)) / sr
    if len(data.shape) > 1:
        jammer_mono = jam_amp * np.sin(2 * np.pi * jam_freq * t)
        jammer = np.column_stack((jammer_mono, jammer_mono))
    else:
        jammer = jam_amp * np.sin(2 * np.pi * jam_freq * t)
    return data + jammer

# =====================================
# 2. HÀM TÍNH TOÁN BER
# =====================================

def calculate_ber(orig_file, ext_file):
    try:
        with open(orig_file, 'r') as f1: orig_bits = f1.read().strip()
        with open(ext_file, 'r') as f2: ext_bits = f2.read().strip()
    except Exception:
        return 1.0 # Lỗi đọc file coi như sai 100%

    total_orig = len(orig_bits)
    if total_orig == 0: return 1.0
    
    errors = 0
    for i in range(total_orig):
        if i >= len(ext_bits):
            errors += 1 # Mất bit
        elif orig_bits[i] != ext_bits[i]:
            errors += 1

    return errors / total_orig

# =====================================
# MAIN ROUTINE (AUTOMATED PIPELINE)
# =====================================

def main():
    if len(sys.argv) != 4:
        print("Usage: python3 attack_noise.py <attack_type> <stego_fhss.wav> <stego_dsss.wav>")
        sys.exit(1)

    attack_type = sys.argv[1].lower()
    fhss_in = sys.argv[2]
    dsss_in = sys.argv[3]

    print(f"\n[*] ĐANG THÊM NHIỄU: {attack_type.upper()}")
    
    # -------------------------------------
    # BƯỚC 1: XỬ LÝ TẤN CÔNG FILE FHSS
    # -------------------------------------
    fhss_data, fhss_sr = sf.read(fhss_in)
    if attack_type == 'awgn':
        att_fhss = add_broadband_noise(fhss_data, 0.005)
        out_fhss = "attacked_awgn_fhss.wav"
    else:
        att_fhss = add_narrowband_noise(fhss_data, fhss_sr, 5000, 0.05)
        out_fhss = "attacked_narrow_fhss.wav"
        
    m_fhss = np.max(np.abs(att_fhss))
    if m_fhss > 1.0: att_fhss /= m_fhss
    sf.write(out_fhss, att_fhss.astype(np.float32), fhss_sr)
    
    # -------------------------------------
    # BƯỚC 2: XỬ LÝ TẤN CÔNG FILE DSSS
    # -------------------------------------
    dsss_data, dsss_sr = sf.read(dsss_in)
    if attack_type == 'awgn':
        att_dsss = add_broadband_noise(dsss_data, 0.005)
        out_dsss = "attacked_awgn_dsss.wav"
    else:
        att_dsss = add_narrowband_noise(dsss_data, dsss_sr, 5000, 0.05)
        out_dsss = "attacked_narrow_dsss.wav"
        
    m_dsss = np.max(np.abs(att_dsss))
    if m_dsss > 1.0: att_dsss /= m_dsss
    sf.write(out_dsss, att_dsss.astype(np.float32), dsss_sr)

    print(f"[+] Đã tạo xong 2 file nhiễu: {out_fhss} và {out_dsss}")

    # -------------------------------------
    # BƯỚC 3: TỰ ĐỘNG GỌI SCRIPT GIẢI MÁ
    # -------------------------------------
    print("[*] Đang tự động kích giải mã file được thêm nhiễu")
    
    # Chạy extract_fhss.py ẩn output đi để console gọn gàng
    subprocess.run([sys.executable, "extract_fhss.py", out_fhss], 
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    # Chạy extract_dsss.py ẩn output đi
    subprocess.run([sys.executable, "extract_dsss.py", out_dsss], 
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    # -------------------------------------
    # BƯỚC 4: TÍNH BER & HIỂN THỊ SO SÁNH
    # -------------------------------------
    ber_fhss = calculate_ber("original_bits_fhss.txt", "extracted_bits_fhss.txt")
    ber_dsss = calculate_ber("original_bits_dsss.txt", "extracted_bits_dsss.txt")

    print("\n" + "="*50)
    print(" KẾT QUẢ ĐO BER".center(50))
    print("="*50)
    print(f"{'Nhiễu nền dải rộng (AWGN):' if attack_type == 'awgn' else 'Máy phá sóng (Narrowband Jammer)'}")
    print(f"BER của FHSS      : {ber_fhss * 100:>6.2f} %")
    print(f"BER của DSSS      : {ber_dsss * 100:>6.2f} %")
    print("-" * 50)
    
    # Đưa ra kết luận tự động
    if attack_type == 'awgn':
        if ber_dsss < ber_fhss:
            print("DSSS có khả năng chống nhiễu trắng tốt hơn FHSS!")
        else:
            print("Lưu ý: Bạn có thể cần tăng mức nhiễu AWGN để thấy rõ sự khác biệt.")
    elif attack_type == 'narrow':
        if ber_fhss < ber_dsss:
            print("FHSS có khả năng chống nhiễu băng hẹp tốt hơn DSSS!")
        else:
            print("Lưu ý: Bạn có thể cần tăng biên độ Jammer (jam_amp) để thấy rõ DSSS bị phá hủy.")
    print("="*50 + "\n")

if __name__ == "__main__":
    main()
