#attack_noise
import numpy as np
import soundfile as sf
import sys
import subprocess
import os

# =====================================
# 1. CÁC HÀM TẠO NHIỄU (ATTACKS)
# =====================================

def add_broadband_noise(data, noise_level=0.002): # AWGN ở mức 0.002
    # Fix cố định nhiễu để các lần test ra kết quả ổn định
    np.random.seed(42) 
    noise = np.random.normal(0, noise_level, data.shape)
    return data + noise

def add_narrowband_noise(data, sr, jam_freq=5000, jam_amp=0.02): # Jammer ở mức 0.02
    t = np.arange(len(data)) / sr
    if len(data.shape) > 1:
        jammer_mono = jam_amp * np.sin(2 * np.pi * jam_freq * t)
        jammer = np.column_stack((jammer_mono, jammer_mono))
    else:
        jammer = jam_amp * np.sin(2 * np.pi * jam_freq * t)
    return data + jammer

# =====================================
# 2. HÀM TÍNH TOÁN BER
# =====================================

def calculate_ber(orig_file, ext_file):
    # Nếu file không tồn tại (do code extract bị crash), báo lỗi 100%
    if not os.path.exists(ext_file):
        return 1.0 

    try:
        with open(orig_file, 'r') as f1: orig_bits = f1.read().strip()
        with open(ext_file, 'r') as f2: ext_bits = f2.read().strip()
    except Exception:
        return 1.0 

    total_orig = len(orig_bits)
    if total_orig == 0: return 1.0
    
    # Tính BER không có Preamble
    min_len = min(len(orig_bits), len(ext_bits))
    max_len = max(len(orig_bits), len(ext_bits))
    
    errors = sum(1 for i in range(min_len) if orig_bits[i] != ext_bits[i])
    errors += (max_len - min_len) # Phạt các bit bị thiếu/thừa

    return errors / max_len

# =====================================
# MAIN ROUTINE (AUTOMATED PIPELINE)
# =====================================

def main():
    if len(sys.argv) != 4:
        print("Usage: python attack_noise.py <attack_type> <stego_fhss.wav> <stego_dsss.wav>")
        sys.exit(1)

    attack_type = sys.argv[1].lower()
    fhss_in = sys.argv[2]
    dsss_in = sys.argv[3]

    print(f"\n[*] ĐANG THÊM NHIỄU: {attack_type.upper()}")
    
    # --- ĐÃ THÊM: Dọn rác file cũ để không đọc nhầm ---
    for f in ["extracted_bits_fhss.txt", "extracted_bits_dsss.txt"]:
        if os.path.exists(f):
            os.remove(f)

    # -------------------------------------
    # BƯỚC 1: XỬ LÝ TẤN CÔNG FILE FHSS
    # -------------------------------------
    fhss_data, fhss_sr = sf.read(fhss_in)
    if attack_type == 'awgn':
        att_fhss = add_broadband_noise(fhss_data, 0.002)
        out_fhss = "attacked_awgn_fhss.wav"
    else:
        att_fhss = add_narrowband_noise(fhss_data, fhss_sr, 6000, 0.002)
        out_fhss = "attacked_narrow_fhss.wav"
        
    # --- ĐÃ SỬA: Dùng np.clip thay cho phép chia tỷ lệ ---
    att_fhss = np.clip(att_fhss, -1.0, 1.0)
    sf.write(out_fhss, att_fhss.astype(np.float32), fhss_sr)
    
    # -------------------------------------
    # BƯỚC 2: XỬ LÝ TẤN CÔNG FILE DSSS
    # -------------------------------------
    dsss_data, dsss_sr = sf.read(dsss_in)
    if attack_type == 'awgn':
        att_dsss = add_broadband_noise(dsss_data, 0.002)
        out_dsss = "attacked_awgn_dsss.wav"
    else:
        att_dsss = add_narrowband_noise(dsss_data, dsss_sr, 6000, 0.002)
        out_dsss = "attacked_narrow_dsss.wav"
        
    # --- ĐÃ SỬA: Dùng np.clip thay cho phép chia tỷ lệ ---
    att_dsss = np.clip(att_dsss, -1.0, 1.0)
    sf.write(out_dsss, att_dsss.astype(np.float32), dsss_sr)

    print(f"[+] Đã tạo xong 2 file nhiễu: {out_fhss} và {out_dsss}")

    # -------------------------------------
    # BƯỚC 3: TỰ ĐỘNG GỌI SCRIPT GIẢI MÃ
    # -------------------------------------
    print("[*] Đang tự động kích hoạt giải mã")
    
    # --- ĐÃ SỬA: Bỏ DEVNULL để xem được lỗi nếu thuật toán sập ---
    subprocess.run([sys.executable, "extract_fhss.py", out_fhss])
    subprocess.run([sys.executable, "extract_dsss.py", out_dsss])

    # -------------------------------------
    # BƯỚC 4: TÍNH BER & HIỂN THỊ SO SÁNH
    # -------------------------------------
    ber_fhss = calculate_ber("original_bits_fhss.txt", "extracted_bits_fhss.txt")
    ber_dsss = calculate_ber("original_bits_dsss.txt", "extracted_bits_dsss.txt")

    print("\n" + "="*50)
    print(" KẾT QUẢ ĐO BER".center(50))
    print("="*50)
    print(f"{'Nhiễu nền dải rộng (AWGN):' if attack_type == 'awgn' else 'Nhiễu băng hẹp '}")
    print(f"BER của FHSS      : {ber_fhss:.3f}")
    print(f"BER của DSSS      : {ber_dsss:.3f}")
    print("-" * 50)
    
    # Đưa ra kết luận tự động
    if attack_type == 'awgn':
        if ber_dsss < ber_fhss:
            print("DSSS có khả năng chống nhiễu trắng tốt hơn FHSS!")
        else:
            print("Lưu ý: Bạn có thể cần tăng mức nhiễu AWGN để thấy rõ sự khác biệt.")
    elif attack_type == 'narrow':
        if ber_fhss < ber_dsss:
            print("FHSS có khả năng chống nhiễu băng hẹp tốt hơn DSSS!")
        else:
            print("Lưu ý: Bạn có thể cần tăng biên độ Jammer để thấy rõ DSSS bị phá hủy.")
    print("="*50 + "\n")

if __name__ == "__main__":
    main()
