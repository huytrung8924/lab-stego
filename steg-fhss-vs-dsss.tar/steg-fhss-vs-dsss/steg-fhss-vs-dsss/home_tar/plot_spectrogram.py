import matplotlib.pyplot as plt
import soundfile as sf
import sys

if len(sys.argv) != 4:
    print("Usage: python3 plot_spectrogram.py host_audio.wav stego_audio_fhss.wav stego_audio_dsss.wav")
    sys.exit(1)

files = [sys.argv[1], sys.argv[2], sys.argv[3]]
titles = ["1. Âm thanh gốc (Host)", "2. Giấu tin FHSS", "3. Giấu tin DSSS"]

plt.figure(figsize=(15, 5))

for i, f in enumerate(files):
    data, fs = sf.read(f)

    # Nếu stereo thì lấy 1 kênh
    if len(data.shape) > 1:
        data = data[:, 0]

    # Zoom 2 giây đầu
    data = data[:fs * 2]

    plt.subplot(1, 3, i + 1)

    plt.specgram(
        data,
        Fs=fs,
        cmap='magma'
    )

    plt.title(titles[i])
    plt.ylabel('Tần số (Hz)')
    plt.xlabel('Thời gian (s)')

    # Giới hạn vùng tần số để nhìn rõ vùng embed
    plt.ylim(0, 8000)

plt.tight_layout()

# Hiển thị ảnh trực tiếp
plt.show()
