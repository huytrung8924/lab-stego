#extract_dsss.py
import numpy as np
import soundfile as sf
import hashlib
import sys
from scipy.signal import butter, filtfilt

# =====================================
# CONFIG (Phải khớp với file embed)
# =====================================
BIT_DURATION = 0.03
BASE_FREQ = 5000
SECRET_KEY = "DSSS_SECRET"

# =====================================
# MODULE BỘ LỌC THÔNG CAO (HIGH-PASS FILTER)
# =====================================
def butter_highpass_filter(data, cutoff, fs, order=5):
    # Tạo bộ lọc Butterworth để cắt bỏ các tần số thấp (nhạc nền)
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    # filtfilt giúp lọc tín hiệu mà không làm lệch pha (Zero-phase)
    y = filtfilt(b, a, data)
    return y

# =====================================
# MAIN
# =====================================
def main():
    if len(sys.argv) < 2:
        print("Usage: python3 extract_dsss.py stego_audio_dsss.wav")
        sys.exit(1)

    stego_file = sys.argv[1]

    try:
        data, SR = sf.read(stego_file)
    except Exception as e:
        print(f"[-] Lỗi khi đọc file: {e}")
        sys.exit(1)

    if len(data.shape) > 1:
        data = data[:, 0]

    clean_data = butter_highpass_filter(data, 3000, SR)

    samples_per_bit = int(BIT_DURATION * SR)
    total_bits_est = len(clean_data) // samples_per_bit
    total_samples = total_bits_est * samples_per_bit

    seed = int(hashlib.sha256(SECRET_KEY.encode()).hexdigest(), 16) % (2**32)
    np.random.seed(seed)

    pn_sequence = np.random.choice([-1, 1], size=total_samples)
    t = np.arange(total_samples) / SR
    carrier = np.sin(2 * np.pi * BASE_FREQ * t)

    extracted_bits = ""

    for i in range(total_bits_est):
        start_idx = i * samples_per_bit
        end_idx = start_idx + samples_per_bit
        
        # [QUAN TRỌNG] Sử dụng clean_data (đã lọc nền) thay vì data gốc
        chunk = clean_data[start_idx:end_idx]
        pn_chunk = pn_sequence[start_idx:end_idx]
        carrier_chunk = carrier[start_idx:end_idx]
        
        correlation = np.sum(chunk * pn_chunk * carrier_chunk)
        
        if correlation > 0:
            extracted_bits += "1"
        else:
            extracted_bits += "0"

    # Trim extracted bits to original message length if available
    try:
        with open("original_bits_dsss.txt", "r") as lf:
            total_bits = len(lf.read().strip())
            trimmed = extracted_bits[:total_bits]
    except Exception:
        print("[-] Không tìm thấy original_bits_dsss.txt")
        trimmed = extracted_bits

    with open("extracted_bits_dsss.txt", "w") as f:
        f.write(trimmed)

    print("[+] Saved: extracted_bits_dsss.txt")

    message = ""

    for i in range(0, len(trimmed), 8):
        byte = trimmed[i:i+8]
        if len(byte) < 8:
            break

        if byte == "00000000":
            break

        message += chr(int(byte, 2))

    print("\n[+] Message:")
    print(message)

if __name__ == "__main__":
    main()

