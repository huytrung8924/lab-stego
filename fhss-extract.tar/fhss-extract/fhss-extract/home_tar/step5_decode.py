import sys
import os

# =========================
# CHECK INPUT
# =========================
if len(sys.argv) != 2:
    print("\n[!] Usage:")
    print("python step5_decode.py <payload_bits.txt>\n")
    sys.exit(1)

input_file = sys.argv[1]

# =========================
# LOAD BITS
# =========================
if not os.path.exists(input_file):
    print(f"[!] File not found: {input_file}")
    sys.exit(1)

bits = open(input_file).read().strip()

# =========================
# DECODE
# =========================
message = ""

for i in range(0, len(bits), 8):

    byte = bits[i:i+8]

    if len(byte) < 8:
        break

    value = int(byte, 2)

    if value == 0:   # NULL terminator
        break

    message += chr(value)

# =========================
# OUTPUT
# =========================
print()
print("Recovered Message:")
print()
print(message)
