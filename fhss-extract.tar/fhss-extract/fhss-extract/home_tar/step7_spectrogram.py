import soundfile as sf
import matplotlib.pyplot as plt
from scipy.signal import spectrogram

signal, sr = sf.read(
    "noisy.wav"
)

f, t, Sxx = spectrogram(
    signal,
    sr
)

plt.pcolormesh(
    t,
    f,
    Sxx
)

plt.ylabel("Frequency")

plt.xlabel("Time")

plt.title(
    "FHSS Spectrogram"
)

plt.show()
