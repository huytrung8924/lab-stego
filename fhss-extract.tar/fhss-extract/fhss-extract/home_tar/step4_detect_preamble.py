PREAMBLE = "1010101111001101"

with open(
    "extracted_bits.txt"
) as f:

    bits = f.read()

index = bits.find(
    PREAMBLE
)

if index == -1:

    print(
        "[-] PREAMBLE NOT FOUND"
    )

else:

    print(
        "[+] PREAMBLE FOUND"
    )

    print(
        "INDEX =",
        index
    )

    payload = bits[
        index + len(PREAMBLE):
    ]

    # THÊM PHẦN IN RA BIT THU ĐƯỢC
    print(
        "[+] PAYLOAD BITS:"
    )
    print(
        payload
    )

    with open(
        "payload_bits.txt"
    , "w") as f:

        f.write(payload)
