import sys

if len(sys.argv) != 3:
    print("Usage: python step6_ber.py <extracted_bits.txt> <original_bits.txt>")
    sys.exit(1)

extracted_file = sys.argv[1]
original_file = sys.argv[2]

a = open(original_file).read()
b = open(extracted_file).read()

n = min(len(a), len(b))

errors = 0

for i in range(n):
    if a[i] != b[i]:
        errors += 1

ber = errors / n if n > 0 else 0

print()
print("TOTAL =", n)
print("ERRORS =", errors)
print("BER =", ber)
