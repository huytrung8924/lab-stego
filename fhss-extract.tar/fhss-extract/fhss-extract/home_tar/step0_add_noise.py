import numpy as np
import soundfile as sf
import sys

signal, sr = sf.read(sys.argv[1])

print("[+] Input loaded")
print(f"[+] Sample rate: {sr}")
print(f"[+] Signal length: {len(signal)} samples")

# =========================
# Gaussian noise
# =========================
noise_sigma = 0.03
noise = np.random.normal(0, noise_sigma, signal.shape)
signal = signal + noise

signal_power = np.mean(signal ** 2)
noise_power = np.mean(noise ** 2)

print("[+] Gaussian noise applied")
print(f"    sigma = {noise_sigma}")
print(f"    noise power = {noise_power:.6f}")

# =========================
# Burst noise
# =========================
burst_len = 2000
start = np.random.randint(0, len(signal) - burst_len)

burst_noise = 0.7 * np.random.randn(burst_len)
signal[start:start+burst_len] += burst_noise

print("[+] Burst noise applied")
print(f"    start index = {start}")
print(f"    duration = {burst_len} samples")
print(f"    burst time = {round(start/sr, 3)} sec")

# =========================
# Save output
# =========================
output_file = "noisy.wav"
sf.write(output_file, signal, sr)

print("[+] Output saved:", output_file)
print("[+] Noise injection complete (BER impact mode)")
