import numpy as np
import soundfile as sf
from scipy.signal import butter, lfilter
import sys

SR = 44100
BIT_DURATION = 0.015
BASE_FREQ = 4000
DELTA_HOP = 400

samples_per_bit = int(SR * BIT_DURATION)

# =========================
# CHECK INPUT ARGUMENTS
# =========================
if len(sys.argv) != 3:
    print("\n[!] Usage:")
    print("python step2_dehop.py <noisy.wav> <hopping_pattern.txt>\n")
    sys.exit(1)

input_wav = sys.argv[1]
pattern_file = sys.argv[2]

# =========================
# LOAD AUDIO
# =========================
print(f"[+] Loading {input_wav} ...")

signal, sr = sf.read(input_wav)

print("[+] Audio loaded")
print(f"[+] Signal length: {len(signal)} samples")

# =========================
# LOAD HOPPING PATTERN
# =========================
pattern = []

print(f"[+] Loading hopping pattern: {pattern_file}")

with open(pattern_file) as f:
    for line in f:
        pattern.append(int(line.strip()))

print(f"[+] Total hops: {len(pattern)}")

# =========================
# BANDPASS FILTER
# =========================
def bandpass(data, lowcut, highcut, fs):
    nyq = fs / 2
    low = lowcut / nyq
    high = highcut / nyq

    b, a = butter(4, [low, high], btype='band')
    return lfilter(b, a, data)

# =========================
# DEHOP PROCESS
# =========================
output = np.array([])

print("[+] Starting de-hopping process ...")

for i in range(len(pattern)):

    start = i * samples_per_bit
    end = start + samples_per_bit

    if end > len(signal):
        print("[!] End of signal")
        break

    chunk = signal[start:end]

    hop_freq = BASE_FREQ + pattern[i] * DELTA_HOP

    print(f"[+] Processing hop {i} at {hop_freq} Hz")

    t = np.arange(len(chunk)) / SR
    carrier = np.cos(2 * np.pi * hop_freq * t)

    mixed = chunk * carrier

    filtered = bandpass(mixed, 800, 2500, SR)

    output = np.concatenate((output, filtered))

# =========================
# SAVE OUTPUT
# =========================
print("[+] Saving baseband.wav ...")

sf.write("baseband.wav", output, SR)

print("[+] de-hop complete")
