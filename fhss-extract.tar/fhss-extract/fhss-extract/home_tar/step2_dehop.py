# step2_dehop.py
import sys
import numpy as np
import soundfile as sf

SR = 44100
BIT_DURATION = 0.03
SAMPLES_PER_BIT = int(SR * BIT_DURATION)

BASE_FREQ = 5000
DELTA_FREQ = 300

def fft_bandpass(segment, fs, low_cut, high_cut):
    spectrum = np.fft.rfft(segment)
    freqs = np.fft.rfftfreq(len(segment), d=1/fs)

    mask = (freqs >= low_cut) & (freqs <= high_cut)

    filtered = np.fft.irfft(spectrum * mask, n=len(segment))
    return filtered.astype(np.float32)

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 step2_dehop.py <stego_audio.wav> <hopping_pattern.txt>")
        sys.exit(1)

    stego_file = sys.argv[1]
    pattern_file = sys.argv[2]

    audio, sr = sf.read(stego_file, dtype='float32')

    if len(audio.shape) > 1:
        audio = audio.mean(axis=1)

    if sr != SR:
        print(f"[-] Sample rate phải là {SR}")
        sys.exit(1)

    with open(pattern_file, "r") as f:
        hopping_pattern = [int(x) for x in f.read().strip().split()]

    total_bits = len(hopping_pattern)

    dehopped_signal = np.zeros(
        total_bits * SAMPLES_PER_BIT,
        dtype=np.float32
    )

    print("\n========== FHSS DE-HOPPING ==========")
    print(f"[+] Input audio    : {stego_file}")
    print(f"[+] Total hops     : {total_bits}")
    print(f"[+] Base frequency : {BASE_FREQ} Hz")
    print(f"[+] Delta frequency: {DELTA_FREQ} Hz")

    print("\n[+] Processing de-hopping...")

    for i in range(total_bits):
        start = i * SAMPLES_PER_BIT
        end = start + SAMPLES_PER_BIT

        segment = audio[start:end]

        if len(segment) < SAMPLES_PER_BIT:
            break

        hop = hopping_pattern[i]

        f0 = BASE_FREQ + hop * DELTA_FREQ

        low_cut = f0 - 150
        high_cut = f0 + DELTA_FREQ + 150

        filtered_segment = fft_bandpass(
            segment,
            SR,
            low_cut,
            high_cut
        )

        dehopped_signal[start:end] = filtered_segment

    output_file = "baseband.wav"

    sf.write(output_file, dehopped_signal, SR)

    print(f"[+] Output audio   : {output_file}")
    print("[+] De-hopping completed")
    print("=====================================")

if __name__ == "__main__":
    main()