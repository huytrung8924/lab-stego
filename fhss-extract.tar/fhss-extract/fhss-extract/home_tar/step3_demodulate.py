import numpy as np
import soundfile as sf
import sys

SR = 44100
BIT_DURATION = 0.015
samples_per_bit = int(SR * BIT_DURATION)

# =========================
# CHECK INPUT
# =========================
if len(sys.argv) != 2:
    print("\n[!] Usage:")
    print("python step3_demodulate.py <baseband.wav>\n")
    sys.exit(1)

input_wav = sys.argv[1]

# =========================
# LOAD SIGNAL
# =========================
print(f"[+] Loading {input_wav} ...")

signal, sr = sf.read(input_wav)

print("[+] Audio loaded")

bits = ""

# =========================
# DEMODULATION
# =========================
for i in range(0, len(signal), samples_per_bit):

    chunk = signal[i:i + samples_per_bit]

    if len(chunk) < samples_per_bit:
        break

    fft = np.abs(np.fft.fft(chunk))
    freqs = np.fft.fftfreq(len(chunk), 1 / sr)

    peak = abs(freqs[np.argmax(fft)])

    if peak < 1700:
        bits += "0"
    else:
        bits += "1"

# =========================
# SAVE RESULT
# =========================
with open("extracted_bits.txt", "w") as f:
    f.write(bits)

print("\n[+] FSK demodulation complete")
print("[+] Extracted bits:")
print(bits)
print("\n[+] Saved to extracted_bits.txt")
