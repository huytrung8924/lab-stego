# step3_demodulate.py
import sys
import numpy as np
import soundfile as sf

SR = 44100
BIT_DURATION = 0.03
SAMPLES_PER_BIT = int(SR * BIT_DURATION)

BASE_FREQ = 5000
DELTA_FREQ = 300

def goertzel_power(segment, freq, fs):
    n = len(segment)

    k = int(0.5 + (n * freq / fs))
    omega = (2.0 * np.pi * k) / n
    coeff = 2.0 * np.cos(omega)

    q0, q1, q2 = 0.0, 0.0, 0.0

    window = np.hanning(n)
    segment = (segment - np.mean(segment)) * window

    for sample in segment:
        q0 = coeff * q1 - q2 + sample
        q2 = q1
        q1 = q0

    return q1**2 + q2**2 - q1 * q2 * coeff

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 step3_demodulate.py <baseband.wav> <hopping_pattern.txt>")
        sys.exit(1)

    baseband_file = sys.argv[1]
    pattern_file = sys.argv[2]

    audio, sr = sf.read(baseband_file, dtype='float32')

    if sr != SR:
        print(f"[-] Sample rate phải là {SR}")
        sys.exit(1)

    with open(pattern_file, "r") as f:
        hopping_pattern = [int(x) for x in f.read().strip().split()]

    total_bits = len(hopping_pattern)

    extracted_bits = ""

    print("\n========== FHSS DEMODULATION ==========")
    print(f"[+] Input audio    : {baseband_file}")
    print(f"[+] Total bits     : {total_bits}")

    print("\n[+] Demodulating FSK signals...")

    for i in range(total_bits):
        start = i * SAMPLES_PER_BIT
        end = start + SAMPLES_PER_BIT

        segment = audio[start:end]

        if len(segment) < SAMPLES_PER_BIT:
            break

        hop = hopping_pattern[i]

        f0 = BASE_FREQ + hop * DELTA_FREQ
        f1 = BASE_FREQ + (hop + 1) * DELTA_FREQ

        p0 = goertzel_power(segment, f0, SR)
        p1 = goertzel_power(segment, f1, SR)

        if p1 > p0:
            extracted_bits += '1'
        else:
            extracted_bits += '0'

    output_file = "extracted_bits.txt"

    with open(output_file, "w") as f:
        f.write(extracted_bits)

    print(f"[+] Extracted bits : {extracted_bits}")
    print(f"[+] Saved to       : {output_file}")
    print("[+] Demodulation completed")
    print("=======================================")

if __name__ == "__main__":
    main()