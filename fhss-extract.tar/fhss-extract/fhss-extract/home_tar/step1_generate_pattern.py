# step1_generate_pattern.py
import sys
import hashlib
import random

HOP_RANGE = (1, 8)

def generate_hopping_pattern(length, key):
    seed = int(hashlib.sha256(key.encode()).hexdigest(), 16) % (2**32)
    rng = random.Random(seed)
    return [rng.randint(*HOP_RANGE) for _ in range(length)]

def main():
    if len(sys.argv) != 3:
        print("Usage: python3 step1_generate_pattern.py <length> <secret_key>")
        sys.exit(1)

    length = int(sys.argv[1])
    key = sys.argv[2]

    pattern = generate_hopping_pattern(length, key)

    output_file = "hopping_pattern.txt"

    with open(output_file, "w") as f:
        f.write(" ".join(map(str, pattern)))

    print("\n========== FHSS HOPPING PATTERN ==========")
    print(f"[+] Pattern length : {length}")
    print(f"[+] Hopping pattern: {pattern}")
    print(f"[+] Saved to       : {output_file}")
    print("==========================================")

if __name__ == "__main__":
    main()