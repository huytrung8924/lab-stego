import hashlib
import sys

# ======================
# CHECK ARGUMENTS
# ======================

if len(sys.argv) != 3:

    print()

    print(
        "Usage:"
    )

    print(
        "python3 step1_generate_pattern.py <pattern_length> <secret_key>"
    )

    print()

    sys.exit()

# ======================
# INPUT PARAMETERS
# ======================

length = int(
    sys.argv[1]
)

SECRET_KEY = sys.argv[2]

print()
print("[+] Initializing FHSS synchronization")
print(f"[+] Pattern length : {length}")
print(f"[+] Secret key     : {SECRET_KEY}")

# ======================
# GENERATE SEED
# ======================

seed = int(
    hashlib.sha256(
        SECRET_KEY.encode()
    ).hexdigest(),
    16
)

print("[+] Seed generated from SHA256")

# ======================
# INITIALIZE LFSR
# ======================

state = seed & 0xFFFF

pattern = []

print("[+] Starting LFSR generator ...")

# ======================
# GENERATE HOPPING
# ======================

for _ in range(length):

    new_bit = (
        ((state >> 0) ^
         (state >> 2) ^
         (state >> 3) ^
         (state >> 5)) & 1
    )

    state = (
        (state >> 1) |
        (new_bit << 15)
    )

    pattern.append(state % 8)

print("[+] Hopping sequence generated")

# ======================
# SAVE PATTERN
# ======================

with open(
    "hopping_pattern.txt",
    "w"
) as f:

    for p in pattern:

        f.write(str(p) + "\n")

print()

print("[+] RX hopping created")

print(
    "[+] Saved to hopping_pattern.txt"
)

# ======================
# THÊM PHẦN IN KẾT QUẢ
# ======================

print()
print("[+] HOPPING PATTERN:")

with open("hopping_pattern.txt", "r") as f:
    hops = f.read().strip().split()

print(" ".join(hops))
