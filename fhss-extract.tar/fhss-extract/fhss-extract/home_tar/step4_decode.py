# step4_decode.py
import sys

PREAMBLE_SYNC = '1010101010101010'
PREAMBLE_LEN_BITS = 32

def bits_to_text(bits):
    chars = []

    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]

        if len(byte) < 8:
            continue

        chars.append(chr(int(byte, 2)))

    return ''.join(chars)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 step4_decode.py <extracted_bit.txt>")
        sys.exit(1)

    bit_file = sys.argv[1]

    with open(bit_file, "r") as f:
        extracted_bits = f.read().strip()

    print("\n========== FHSS MESSAGE DECODING ==========")
    print(f"[+] Input bits file : {bit_file}")
    print(f"[+] Total bits      : {len(extracted_bits)}")

    sync_idx = extracted_bits.find(PREAMBLE_SYNC)

    if (
        sync_idx != -1 and
        sync_idx + len(PREAMBLE_SYNC) + PREAMBLE_LEN_BITS <= len(extracted_bits)
    ):

        header_start = sync_idx + len(PREAMBLE_SYNC)

        len_bits_str = extracted_bits[
            header_start:header_start + PREAMBLE_LEN_BITS
        ]

        try:
            payload_len = int(len_bits_str, 2)

            payload_start = header_start + PREAMBLE_LEN_BITS

            payload_bits = extracted_bits[
                payload_start: payload_start + payload_len
            ]

            print(f"[+] Preamble found : Bit index {sync_idx}")
            print(f"[+] Payload length : {payload_len} bits")

        except Exception:
            print("[-] Invalid payload length field")
            payload_bits = extracted_bits

    else:
        print("[-] No preamble found")
        payload_bits = extracted_bits

    message = bits_to_text(payload_bits)

    print("\n[+] Recovered message:")
    print("----------------------------------")
    print(message)
    print("----------------------------------")

    print("[+] Decoding completed")
    print("==========================================")

if __name__ == "__main__":
    main()