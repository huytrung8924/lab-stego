import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
import sys

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 analyze_spectrogram.py <audio.wav>")
        sys.exit(1)

    file_path = sys.argv[1]
    data, sr = sf.read(file_path)
    
    if len(data.shape) > 1:
        data = data.mean(axis=1)

    print("[+] Đang phân tích Phổ đồ (Spectrogram)...")
    
    plt.figure(figsize=(12, 6))
    
    # Sử dụng NFFT lớn để tăng độ phân giải tần số
    plt.specgram(data, Fs=sr, NFFT=2048, noverlap=1024, cmap='magma')
    
    plt.title(f"Spectrogram Analysis - {file_path}")
    plt.xlabel("Thời gian (s)")
    plt.ylabel("Tần số (Hz)")
    
    # Hiển thị dải tần từ 0 đến 10kHz (Khu vực thường bị lợi dụng để giấu tin âm thanh)
    plt.ylim(0, 10000)
    plt.colorbar(label='Cường độ (dB)')
    
    plt.tight_layout()
    # Hiển thị trực tiếp đồ thị để tương tác
    plt.show()

if __name__ == "__main__":
    main()