import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
import sys

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 analyze_fft.py <audio.wav>")
        sys.exit(1)

    file_path = sys.argv[1]
    data, sr = sf.read(file_path)
    
    if len(data.shape) > 1:
        data = data.mean(axis=1)

    print("[+] Đang phân tích Phổ tần số (FFT)...")
    
    n = len(data)
    fft_result = np.abs(np.fft.fft(data))
    freqs = np.fft.fftfreq(n, 1/sr)
    
    half_n = n // 2
    freqs = freqs[:half_n]
    fft_result = fft_result[:half_n]

    plt.figure(figsize=(14, 7))
    plt.plot(freqs, fft_result, color='red', linewidth=0.7)
    
    plt.title(f"FFT Spectrum Analysis- {file_path}")
    plt.xlabel("Tần số (Hz)")
    plt.ylabel("Biên độ")
    
    plt.xlim(3000, 10000)
    
    # Auto-scale trục Y cho khu vực này để tránh bị mờ nhạt bởi năng lượng nhạc nền
    mask = (freqs > 4000) & (freqs < 10000)
    y_max_local = np.max(fft_result[mask])
    plt.ylim(0, y_max_local * 1.5)

 
    plt.xticks(np.arange(3000, 10001, 500))
    plt.grid(True, which='major', color='black', linestyle='-', alpha=0.2)
 
    plt.minorticks_on()
    plt.grid(True, which='minor', color='gray', linestyle=':', alpha=0.4)
    # ========================================================
    
    plt.tight_layout()
    # Hiển thị trực tiếp đồ thị
    plt.show()

if __name__ == "__main__":
    main()