import numpy as np
import matplotlib.pyplot as plt
import soundfile as sf
from scipy.signal import butter, filtfilt, hilbert, medfilt
import matplotlib.ticker as ticker
import sys

def butter_highpass(cutoff, fs, order=5):
    nyq = 0.5 * fs
    normal_cutoff = cutoff / nyq
    b, a = butter(order, normal_cutoff, btype='high', analog=False)
    return b, a

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 analyze_time.py <audio.wav>")
        sys.exit(1)

    file_path = sys.argv[1]
    
    try:
        data, sr = sf.read(file_path)
    except Exception as e:
        print(f"[-] Lỗi đọc file: {e}")
        sys.exit(1)
        
    if len(data.shape) > 1:
        data = data.mean(axis=1)

    print("[+] Đang cô lập dải tần bằng Bộ lọc thông cao (>4500Hz)...")
    b, a = butter_highpass(cutoff=4500, fs=sr, order=6)
    filtered_data = filtfilt(b, a, data)

    print("[+] Đang giải điều chế biên độ/pha bằng Biến đổi Hilbert...")
    analytic_signal = hilbert(filtered_data)
    instantaneous_phase = np.unwrap(np.angle(analytic_signal))
    
    instantaneous_frequency = (np.diff(instantaneous_phase) / (2.0 * np.pi) * sr)

    window_size = int(sr * 0.005)
    if window_size % 2 == 0: window_size += 1
    smoothed_freq = medfilt(instantaneous_frequency, kernel_size=window_size)

    start_time = 1.0  
    duration_to_plot = 0.3  
    start_idx = int(start_time * sr)
    end_idx = start_idx + int(duration_to_plot * sr)
    
    segment_t = np.arange(start_idx, end_idx - 1) / sr
    segment_freq = smoothed_freq[start_idx:end_idx - 1]

    plt.figure(figsize=(14, 6))
    plt.plot(segment_t, segment_freq, color='blue', linewidth=1.5)
    
    plt.title("Time-domain analysis", fontsize=12, fontweight='bold')
    plt.xlabel("Thời gian (giây)")
    plt.ylabel("Tần số phát xạ thực tế (Hz)")
    
    plt.xlim(start_time, start_time + duration_to_plot)
    plt.ylim(4500, 8500)

    plt.xticks(np.arange(start_time, start_time + duration_to_plot + 0.01, 0.05))
    plt.gca().xaxis.set_minor_locator(ticker.MultipleLocator(0.01))
    
    plt.yticks(np.arange(4500, 8501, 500))
    plt.gca().yaxis.set_minor_locator(ticker.MultipleLocator(100))

    plt.grid(True, which='major', color='black', linestyle='-', alpha=0.3)
    plt.grid(True, which='minor', color='gray', linestyle=':', alpha=0.5)
    
    plt.tight_layout()
    plt.show()

if __name__ == "__main__":
    main()